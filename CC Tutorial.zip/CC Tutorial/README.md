# ZGB-template
a template for projects using ZGB, the engine I developed for the orginal Game Boy
